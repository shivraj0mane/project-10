var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["1ccfb223-2a8b-42bb-86e2-882003ea3491","2c699040-6351-4654-b36d-3832bdfe0637","bcbfe6d9-bca7-4062-9da0-5d0c2d361d76","e9ddcb0a-4806-44bd-b449-0b2899751422","759418eb-2eca-49a0-b75e-332a85a17e8b","76fd2007-65f3-4bdc-a72c-4ecfafea541d","6fdebf1f-25b9-402d-b25b-cf02fc62e7d1","cadae4a0-de7a-49d6-aa6e-36de43f60406"],"propsByKey":{"1ccfb223-2a8b-42bb-86e2-882003ea3491":{"name":"sports_scoccer_1","sourceUrl":null,"frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"TGnZ_39AXUco4QR0V5YWkyDqqc8iR2bT","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/1ccfb223-2a8b-42bb-86e2-882003ea3491.png"},"2c699040-6351-4654-b36d-3832bdfe0637":{"name":"sports_football_1","sourceUrl":"assets/api/v1/animation-library/gamelab/gzADRGzbQf2w7RKSLQsefPfwox1LVnPS/category_backgrounds/sports_football.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"gzADRGzbQf2w7RKSLQsefPfwox1LVnPS","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/gzADRGzbQf2w7RKSLQsefPfwox1LVnPS/category_backgrounds/sports_football.png"},"bcbfe6d9-bca7-4062-9da0-5d0c2d361d76":{"name":"kid_32_1","sourceUrl":"assets/api/v1/animation-library/gamelab/jH3qCXpeFfa7Er3O_fNy6.GGgap8YLrU/category_people/kid_32.png","frameSize":{"x":180,"y":267},"frameCount":1,"looping":true,"frameDelay":2,"version":"jH3qCXpeFfa7Er3O_fNy6.GGgap8YLrU","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":180,"y":267},"rootRelativePath":"assets/api/v1/animation-library/gamelab/jH3qCXpeFfa7Er3O_fNy6.GGgap8YLrU/category_people/kid_32.png"},"e9ddcb0a-4806-44bd-b449-0b2899751422":{"name":"baby_robot_1","sourceUrl":"assets/api/v1/animation-library/gamelab/96dctbYxFW5wNybomhBpG9RbT5KeXuKO/category_robots/baby_robot.png","frameSize":{"x":240,"y":300},"frameCount":1,"looping":true,"frameDelay":2,"version":"96dctbYxFW5wNybomhBpG9RbT5KeXuKO","categories":["robots"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":240,"y":300},"rootRelativePath":"assets/api/v1/animation-library/gamelab/96dctbYxFW5wNybomhBpG9RbT5KeXuKO/category_robots/baby_robot.png"},"759418eb-2eca-49a0-b75e-332a85a17e8b":{"name":"cave_1","sourceUrl":null,"frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"cPsjeocn90t3c6lj9EG1h1T.Y3s3QIUy","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/759418eb-2eca-49a0-b75e-332a85a17e8b.png"},"76fd2007-65f3-4bdc-a72c-4ecfafea541d":{"name":"cave_2","sourceUrl":"assets/api/v1/animation-library/gamelab/In3iY920nuOrZ0JmAOQbuVG8j8D4iTGD/category_backgrounds/background_cave.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"In3iY920nuOrZ0JmAOQbuVG8j8D4iTGD","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/In3iY920nuOrZ0JmAOQbuVG8j8D4iTGD/category_backgrounds/background_cave.png"},"6fdebf1f-25b9-402d-b25b-cf02fc62e7d1":{"name":"sports_hockey_1","sourceUrl":null,"frameSize":{"x":396,"y":374},"frameCount":1,"looping":true,"frameDelay":12,"version":"P6V1BfUUDen7ltZTA_fVaRt7HtCyGTc4","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":396,"y":374},"rootRelativePath":"assets/6fdebf1f-25b9-402d-b25b-cf02fc62e7d1.png"},"cadae4a0-de7a-49d6-aa6e-36de43f60406":{"name":"animation_1","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"Aht.9EOemmgi_fXSeq6AB41VvAQy7YmH","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/cadae4a0-de7a-49d6-aa6e-36de43f60406.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var b = createSprite(200, 200,400,400);
b.setAnimation("sports_hockey_1");


 var playerMallet;
 
var goal1=createSprite(200,18,100,20);
goal1.shapeColor=("yellow");

var goal2=createSprite(200,382,100,20);
goal2.shapeColor=("yellow");


// making court
var boundary1 = createSprite(200,0,400,10);
boundary1.shapeColor = "white";
var boundary2 = createSprite(200,400,400,10);
boundary2.shapeColor = "white";
var boundary3 = createSprite(0,200,10,400);
boundary3.shapeColor = "white";
var boundary4 = createSprite(400,200,10,400);
boundary4.shapeColor = "white";



// creating objects and giving them colours
var striker = createSprite(200,200,10,10);
striker.shapeColor = "white";
striker.setAnimation("animation_1");


var playerMallet = createSprite(200,50,50,10);
playerMallet.shapeColor = "black";
playerMallet.setAnimation("kid_32_1");

var computerMallet = createSprite(200,350,50,10);
computerMallet.shapeColor = "black";
computerMallet.setAnimation("baby_robot_1");
//score variables
var playerScore=0;
var compScore=0;




var gameState ="serve"; 
 

function draw() {
  
  //clear the screen

background("white");

striker.scale = 0.3;
playerMallet.scale = 0.3;
computerMallet.scale = 0.2;
    
  
 
    
 textSize(18);
  fill("maroon");
  text("compScore : "+compScore,25,225);
  text("playerScore : "+playerScore,25,185);
   
  computerMallet.x=striker.x
    //draw line at the centre
   for (var i = 0; i < 400; i=i+20) {
    line(i,200,i+10,200);

   }

if (gameState==="serve") { 

  textSize(30) ;
  fill("red") ;
   text("press space to strike",120,180);
   
if (keyDown("space")) { 
striker.velocityY = 8;
striker.velocityX = 8;

gameState = "play";
}

}


  
  
if (gameState==("play")){  
  


  
 if(keyDown("left")){
    playerMallet.x = playerMallet.x-10;
    
  }
  
  if(keyDown("right")){
    playerMallet.x = playerMallet.x+10;
    
  }
  
  if(keyDown("up")){
   if(playerMallet.y>25)
   {
    playerMallet.y = playerMallet.y- 10;
   }
  }
  
  if(keyDown("down")){
    if(playerMallet.y<120)
   {
    playerMallet.y = playerMallet.y+10;
   }
  
}
 if(striker.isTouching(goal1))
      { //increment the score of the player
       compScore++ ;
        //use show grid to identify the  value of x and y to bring striker to center
        striker.x=200;
        striker.y=200;
        striker.velocityX=0;
        striker.velocityY=0; 
      gameState = "serve";
      }
      
      if(striker.isTouching(goal2))
      {
        playerScore =  + 1;
        //Reset the striker by adding center value of x and y 
        striker.x=200;
        striker.y=200;
        striker.velocityX=0;
        striker.velocityY=0;
        gameState = "serve";
      }
      
if(playerScore===5)

      {
     
        fill("maroon");
        textSize(80);
        //add the text for won
        text("you won ",170,160);
       stricker.velocityX =0;
       stricker.velocityY =0;
      }
      
       if(compScore===5)

      {
        fill("maroon");
        textSize(30);
        //add the text for GameOver
        text("GAMER OVER ",170,160);
       stricker.velocityX =0;
       stricker.velocityY =0;
       gameState="end";
       
      }
      
      } 

      
if (gameState==("end")){
        fill("maroon");
        textSize(30);
        //add the text for GameOver
        text("GAMER OVER ",170,160);

gameState="serve"
}
  createEdgeSprites();
  
   
  
  striker.bounceOff(edges);
 striker.bounceOff(playerMallet);
  striker.bounceOff(computerMallet);
  playerMallet.bounceOff(edges);
computerMallet.bounceOff(edges);

  

drawSprites();

}
  
  













                                                           
// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
